function onload(){
    grafico();
    //initMap();
}